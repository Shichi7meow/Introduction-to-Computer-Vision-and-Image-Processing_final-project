import cv2

# 1. 載入訓練好的 Haar cascade xml
# cascade_path = "C:\Users\seven\opencv_class_example_practice\final_project\classifier_output\YZU_Seventh_building\cascade.xml"# 'cascade.xml'  # 改成你的cascade.xml路徑
cascade_path = r"C:\Users\seven\opencv_class_example_practice\final_project\classifier_output\YZU_Seventh_building\cascade.xml"

cascade = cv2.CascadeClassifier(cascade_path)

# 2. 開啟攝影機（0是筆電內建攝影機）
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        print("無法從攝影機讀取影像")
        break

    # 3. 將影像轉成灰階（Haar偵測器通常對灰階影像效果較好）
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # 4. 使用cascade做物件偵測
    buildings = cascade.detectMultiScale(
        gray,
        scaleFactor=1.05,    # 比較細緻地縮放圖像，增加偵測準確度，但速度會變慢
        minNeighbors=20,      # 要求至少20個鄰近正樣本，減少誤報
        minSize=(200, 200)   # 建築物比較大，設定較大的最小尺寸，避免小區域誤報
    )

    # 只保留最大的框
    if len(buildings) > 0:
        largest = max(buildings, key=lambda rect: rect[2] * rect[3])  # 找出面積最大的框
        buildings = [largest]

    # # 5. 將偵測到的結果標示在影像上
    # for (x, y, w, h) in buildings:
    #     cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
    #     # 你可以改成你想顯示的建築物名稱
    #     cv2.putText(frame, "Seven Building", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
# ------------------------------------------------
    for (x, y, w, h) in buildings:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.putText(frame, f"Detections: {len(buildings)}", (10,30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)
# ------------------------------------------------
    # h, w = gray.shape[:2]
    # frame_area = w * h

    # filtered_buildings = []
    # for (x, y, bw, bh) in buildings:
    #     area = bw * bh
    #     if area > frame_area * 0.3:  # 建築至少佔30%
    #         filtered_buildings.append((x, y, bw, bh))

    # # 只保留最大的
    # if filtered_buildings:
    #     largest = max(filtered_buildings, key=lambda rect: rect[2] * rect[3])
    #     buildings = [largest]
    # else:
    #     buildings = []

    # 6. 顯示影像
    cv2.imshow("Seven Building Detection", frame)

    # 7. 按 q 鍵結束
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

    if buildings:
        x, y, w, h = buildings[0]
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        memory_text = "這是七館，我在這邊上過影像處理的課！"
        cv2.putText(frame, memory_text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)

cap.release()
cv2.destroyAllWindows()
