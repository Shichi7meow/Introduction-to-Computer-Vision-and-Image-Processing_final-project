import cv2

# 1. 載入訓練好的 Haar cascade
cascade_path = r"C:\Users\seven\opencv_class_example_practice\final_project\classifier_output\YZU_Seventh_building\cascade.xml"
cascade = cv2.CascadeClassifier(cascade_path)

# 2. 開啟攝影機（0是內建攝影機）
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        print("無法從攝影機讀取影像")
        break

    # 3. 灰階處理（提高偵測效果）
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # 4. 偵測七館建築（設定大建築篩選條件）
    buildings = cascade.detectMultiScale(
        gray,
        scaleFactor=1.05,
        minNeighbors=20,
        minSize=(200, 200)
    )

    # 5. 只保留面積最大的框（通常只會有一棟）
    if len(buildings) > 0:
        largest = max(buildings, key=lambda rect: rect[2] * rect[3])
        x, y, w, h = largest

        # 標出框與記憶文字
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        memory_text = "This is the 7th Building. I had image processing class here!"
        cv2.putText(frame, memory_text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)

    # 6. 顯示影像
    cv2.imshow("Seven Building Detection", frame)

    # 7. 按 q 鍵結束
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
