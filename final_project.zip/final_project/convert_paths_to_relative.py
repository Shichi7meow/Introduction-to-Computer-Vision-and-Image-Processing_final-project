import os
import sys

def convert_paths_to_relative_in_folder(info_folder):
    for filename in os.listdir(info_folder):
        if filename.endswith('.txt'):
            info_file = os.path.join(info_folder, filename)
            output_file = os.path.splitext(info_file)[0] + '_relative.txt'

            with open(info_file, 'r', encoding='utf-8') as f_in, open(output_file, 'w', encoding='utf-8') as f_out:
                for line in f_in:
                    line = line.strip()
                    if not line:
                        continue
                    parts = line.split()
                    abs_path = parts[0]

                    try:
                        rel_path = os.path.relpath(abs_path, info_folder)
                    except Exception as e:
                        print(f"Error converting path {abs_path} in file {filename}: {e}")
                        rel_path = abs_path

                    new_line = ' '.join([rel_path] + parts[1:]) + '\n'
                    f_out.write(new_line)

            print(f"已產生: {output_file}")

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("用法: python convert_paths_to_relative.py <info_folder>")
        print("範例: python convert_paths_to_relative.py C:/Users/seven/opencv_class_example_practice/final_project/positive_sample")
        sys.exit(1)

    info_folder = sys.argv[1]

    convert_paths_to_relative_in_folder(info_folder)


# import os
# import sys

# def convert_paths_to_relative(info_folder, info_file):
#     output_file = os.path.splitext(info_file)[0] + '_relative.txt'

#     with open(info_file, 'r', encoding='utf-8') as f_in, open(output_file, 'w', encoding='utf-8') as f_out:
#         for line in f_in:
#             line = line.strip()
#             if not line:
#                 continue
#             parts = line.split()
#             abs_path = parts[0]

#             # 將絕對路徑轉成相對路徑，相對於info_folder
#             try:
#                 rel_path = os.path.relpath(abs_path, info_folder)
#             except Exception as e:
#                 print(f"Error converting path {abs_path}: {e}")
#                 rel_path = abs_path

#             # 重新組合路徑與標註資訊
#             new_line = ' '.join([rel_path] + parts[1:]) + '\n'
#             f_out.write(new_line)

#     print(f"已產生相對路徑的 info 檔: {output_file}")


# if __name__ == '__main__':
#     if len(sys.argv) != 3:
#         print("用法: python convert_paths_to_relative.py <info_folder> <info_file>")
#         print("範例: python convert_paths_to_relative.py C:/Users/seven/opencv_class_example_practice/final_project/positive_sample C:/Users/seven/opencv_class_example_practice/final_project/positive_sample/YZU_Fifth_building_positives.txt")
#         sys.exit(1)

#     info_folder = sys.argv[1]
#     info_file = sys.argv[2]

#     convert_paths_to_relative(info_folder, info_file)
