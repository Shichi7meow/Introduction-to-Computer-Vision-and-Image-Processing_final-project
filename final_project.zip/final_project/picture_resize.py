import os
import cv2
import numpy as np

# input_folder = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\元智一館"
# output_folder = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_First_buinding"

# input_folder = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\元智二館"
# output_folder = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Second_buinding"

# input_folder = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\元智三館"
# output_folder = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Third_buinding"

# input_folder = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\元智五館&圖書館"
# output_folder = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Fifth_buinding_with_library"

# input_folder = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\元智六館"
# output_folder = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Sixth_buinding"

input_folder = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\元智七館"
output_folder = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Seventh_buinding"

# input_folder = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\元智一館"
# output_folder = r"C:\Users\seven\opencv_class_example_practice\resized\元智一館"
os.makedirs(output_folder, exist_ok=True)

def imread_unicode(path):
    """解決中文路徑無法讀圖的問題"""
    with open(path, 'rb') as f:
        data = f.read()
    img_array = np.frombuffer(data, np.uint8)
    img = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
    return img

count = 0
for filename in os.listdir(input_folder):
    if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
        img_path = os.path.join(input_folder, filename)
        img = imread_unicode(img_path)

        if img is None:
            print(f"⚠️ 無法讀取圖片：{img_path}")
            continue

        # Resize 成你要的尺寸（可改成 500x500 等）
        resized = cv2.resize(img, (640, 480))
        output_path = os.path.join(output_folder, filename)
        cv2.imwrite(output_path, resized)
        count += 1

print(f"✅ 完成 resize，共處理 {count} 張圖片。")


# for img_name in os.listdir(input_folder):
#     if img_name.lower().endswith(('.jpg', '.png', '.jpeg')):
#         img_path = os.path.join(input_folder, img_name)
#         img = cv2.imread(img_path)
#         resized = cv2.resize(img, (640, 480)) #(500, 500))  # 你也可以改成 640x480 等
#         cv2.imwrite(os.path.join(output_folder, img_name), resized)

# print("圖片 resize 完成")
