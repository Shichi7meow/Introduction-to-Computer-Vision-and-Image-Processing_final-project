# C:/Users/seven/opencv_class_example_practice/final_report_pictures/元智二館/img001.jpg
# C:/Users/seven/opencv_class_example_practice/final_report_pictures/元智三館/img002.jpg
# ...

import os

# 所有 resize 過的圖片所在的主資料夾
base_path = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized"

# # 指定你不要當負樣本的資料夾名稱（正樣本）
# excluded_folders = ["YZU_First_building"]  # ⚠️ 根據你資料夾命名調整
# # 輸出的負樣本檔案
# output_file = "YZU_First_building_negative.txt"

# # 指定你不要當負樣本的資料夾名稱（正樣本）
# excluded_folders = ["YZU_Second_building"]  # ⚠️ 根據你資料夾命名調整
# # 輸出的負樣本檔案
# output_file = "YZU_Second_building_negative.txt"

# # 指定你不要當負樣本的資料夾名稱（正樣本）
# excluded_folders = ["YZU_Third_building"]  # ⚠️ 根據你資料夾命名調整
# # 輸出的負樣本檔案
# output_file = "YZU_Third_building_negative.txt"

# # 指定你不要當負樣本的資料夾名稱（正樣本）
# excluded_folders = ["YZU_Fifth_building"]  # ⚠️ 根據你資料夾命名調整
# # 輸出的負樣本檔案
# output_file = "YZU_Fifth_building_negative.txt"

# # 指定你不要當負樣本的資料夾名稱（正樣本）
# excluded_folders = ["YZU_Sixth_building"]  # ⚠️ 根據你資料夾命名調整
# # 輸出的負樣本檔案
# output_file = "YZU_Sixth_building_negative.txt"

# 指定你不要當負樣本的資料夾名稱（正樣本）
excluded_folders = ["YZU_Seventh_building"]  # ⚠️ 根據你資料夾命名調整
# 輸出的負樣本檔案
output_file = "YZU_Seventh_building_negative.txt"

# 開始寫入
with open(output_file, "w", encoding="utf-8") as f:
    for folder in os.listdir(base_path):
        if folder in excluded_folders:
            continue  # 跳過正樣本資料夾
        folder_path = os.path.join(base_path, folder)
        if not os.path.isdir(folder_path):
            continue  # 只處理資料夾
        for filename in os.listdir(folder_path):
            if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
                full_path = os.path.join(folder_path, filename)
                full_path = full_path.replace("\\", "/")  # OpenCV 喜歡用斜線
                f.write(full_path + "\n")

print(f"✅ 已產生 {output_file}（排除：{excluded_folders}），請確認內容！")


# import os

# base_path = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized"
# negative_dirs = ["YZU_Second_buinding", "YZU_Third_buinding", "YZU_Fifth_buinding_with_library", "YZU_Sixth_buinding", "YZU_Seventh_buinding"]
# output_file = "negative.txt"

# with open(output_file, "w", encoding="utf-8") as f:
#     for folder in negative_dirs:
#         folder_path = os.path.join(base_path, folder)
#         for filename in os.listdir(folder_path):
#             if filename.lower().endswith(('.jpg', '.png', '.jpeg')):
#                 full_path = os.path.join(folder_path, filename)
#                 full_path = full_path.replace("\\", "/")  # 轉成正斜線格式
#                 f.write(full_path + "\n")

# print(f"negative.txt 已產生，共來自：{negative_dirs}")
