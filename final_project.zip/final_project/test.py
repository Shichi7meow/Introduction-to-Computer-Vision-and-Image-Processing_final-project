import cv2

info_file = "C:/Users/seven/opencv_class_example_practice/final_project/positive_sample/YZU_Seventh_building_positives.txt"

with open(info_file, "r") as f:
    lines = f.readlines()

for line in lines:
    parts = line.strip().split()
    img_path = parts[0]
    obj_num = int(parts[1])
    coords = parts[2:]
    coords = list(map(int, coords))

    img = cv2.imread(img_path)
    if img is None:
        print(f"無法讀取圖片: {img_path}")
        continue

    h, w = img.shape[:2]

    for i in range(obj_num):
        x = coords[4*i]
        y = coords[4*i + 1]
        width = coords[4*i + 2]
        height = coords[4*i + 3]

        if x < 0 or y < 0 or x + width > w or y + height > h:
            print(f"座標超出範圍: {img_path}, x:{x}, y:{y}, w:{width}, h:{height}, img_w:{w}, img_h:{h}")
