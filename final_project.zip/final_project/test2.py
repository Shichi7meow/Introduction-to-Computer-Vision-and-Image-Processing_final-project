import os

# 你的 positive_sample 資料夾
pos_sample_dir = r"C:\Users\seven\opencv_class_example_practice\final_project\positive_sample"

# 影像檔的根目錄
image_root = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized"

for filename in os.listdir(pos_sample_dir):
    if filename.endswith(".txt"):
        txt_path = os.path.join(pos_sample_dir, filename)
        new_lines = []
        with open(txt_path, 'r') as f:
            for line in f:
                parts = line.strip().split()
                abs_path = parts[0]
                # 將絕對路徑轉成相對路徑
                rel_path = os.path.relpath(abs_path, pos_sample_dir)
                # 替換路徑
                new_line = " ".join([rel_path] + parts[1:])
                new_lines.append(new_line)
        # 寫回同一個檔案（或改名備份）
        with open(txt_path, 'w') as f:
            f.write("\n".join(new_lines))
        print(f"Processed {filename}")
