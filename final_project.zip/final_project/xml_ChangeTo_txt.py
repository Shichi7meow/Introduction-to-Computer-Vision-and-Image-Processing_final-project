import os
import glob
import xml.etree.ElementTree as ET

# 路徑設定
# annotations_dir = r"C:\你的XML標註資料夾"
# images_dir = r"C:\你的原始圖片資料夾"
# output_txt = "positives.txt"

# annotations_dir = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Fifth_buinding_with_library\sample_data"
# images_dir = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Fifth_buinding_with_library"
# output_txt = "YZU_Fifth_building_positives.txt"

# annotations_dir = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_First_buinding\sample_data"
# images_dir = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_First_buinding"
# output_txt = "YZU_First_building_positives.txt"

# annotations_dir = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Second_buinding\sample_data"
# images_dir = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Second_buinding"
# output_txt = "YZU_Second_building_positives.txt"

# annotations_dir = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Third_buinding\sample_data"
# images_dir = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Third_buinding"
# output_txt = "YZU_Third_building_positives.txt"

# annotations_dir = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Sixth_buinding\sample_data"
# images_dir = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Sixth_buinding"
# output_txt = "YZU_Sixth_building_positives.txt"

annotations_dir = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Seventh_buinding\sample_data"
images_dir = r"C:\Users\seven\opencv_class_example_practice\final_report_pictures\resized\YZU_Seventh_buinding"
output_txt = "YZU_Seventh_building_positives.txt"



with open(output_txt, "w", encoding="utf-8") as out_file:
    for xml_file in glob.glob(os.path.join(annotations_dir, "*.xml")):
        tree = ET.parse(xml_file)
        root = tree.getroot()

        filename = root.find("filename").text
        image_path = os.path.join(images_dir, filename)
        image_path = image_path.replace("\\", "/")  # OpenCV 不吃反斜線

        objects = root.findall("object")
        line = f"{image_path} {len(objects)}"
        for obj in objects:
            bbox = obj.find("bndbox")
            x = int(float(bbox.find("xmin").text))
            y = int(float(bbox.find("ymin").text))
            w = int(float(bbox.find("xmax").text)) - x
            h = int(float(bbox.find("ymax").text)) - y
            line += f" {x} {y} {w} {h}"
        out_file.write(line + "\n")

print(f"✅ 轉換完成，已輸出到：{output_txt}")
